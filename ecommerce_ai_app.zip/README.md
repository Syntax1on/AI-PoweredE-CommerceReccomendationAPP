# AI-Powered E-Commerce Recommendation App

## Features
- AI-based product suggestions based on user input.

## Setup
- Install dependencies:
```bash
pip install -r requirements.txt
```

- Run:
```bash
python app.py
```

- POST `/recommend` with JSON:
```json
{ "product_query": "laptop for gaming under $1000" }
```