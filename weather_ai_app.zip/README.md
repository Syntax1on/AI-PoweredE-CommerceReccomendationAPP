# AI-Powered Weather App

## Features
- Enter a city/location and get AI-generated weather description.

## Setup
- Install dependencies:
```bash
pip install -r requirements.txt
```

- Run:
```bash
python app.py
```

- POST `/weather` with JSON:
```json
{ "location": "Tokyo" }
```